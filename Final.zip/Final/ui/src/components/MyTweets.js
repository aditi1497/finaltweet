import React, { useEffect, useState } from "react"
import Axios from "axios";
import personLogo from "../components/images/person.jpg";
import deleteLogo from "../components/images/delete.png";
import { getUser, removeButtons,timeFormating } from "../Utils/Common";

const MyTweets = () => {

    const [userData, setuserData] = useState(null);
    removeButtons();
    document.title = "MyTweets";

    const getAllUsers = () => {
        let getuserUrl = `  https://3suvrzt09c.execute-api.us-east-1.amazonaws.com/dev/usertweet/?email=${getUser()}`;

        Axios.get(getuserUrl)
            // eslint-disable-next-line
            .then((respons) => {
                console.log(respons.data);
                let tempdata = respons.data;
                tempdata.sort((a,b) => new Date(b.date)- new Date(a.date));
                console.log(tempdata);
                setuserData(tempdata);
            });
    }

    const handleDeleteTweet = (e) => {
        let deleteUrl = `https://3suvrzt09c.execute-api.us-east-1.amazonaws.com/dev/delete/?tweetId=${e.target.id}`;
        Axios.delete(deleteUrl)
            // eslint-disable-next-line
            .then((respons) => {
                getAllUsers();
            });
    }

    

    useEffect(() => {
        getAllUsers();
    }, []);

    return (
        <div 
        style={{ "alignContent": "centre"  }}     >
            <h1 style={{ "color": "aliceblue", "left": "12%", "position": "relative" }}>
                Your Tweets.
            </h1>
            {userData && userData.map((item, index) => (
                (item.tweetDescription !== "") && (
                    <div
                        key={index}>
                        <div
                            className="usertweet-wrapper">
                            <img
                                src={personLogo}
                                className="personImgUser"
                                alt="avatar">
                            </img>
                            <span
                                style={{ "fontSize": "25px", "color": "black" ,"fontWeight":"bold"}}>
                                {item.tweetDescription}
                            </span><br/>
                            <label
                                style={{ "position": "relative", "top": "-18px" ,"color": "black" ,"left":"60px","fontSize": "25px","fontWeight":"bold"}}>
                                Posted on {timeFormating(new Date(item.date))} ago
                            </label>
                            <label>
                                <img
                                    src={deleteLogo}
                                    alt="delete"
                                    id={item.id}
                                    onClick={handleDeleteTweet}
                                    className="deleteLogo">
                                </img>
                            </label>
                            
                        </div>
                        
                    </div>
                )
            ))}
        </div>
    )
}


export default MyTweets;
