import React, { useState } from "react"
import { NavLink } from 'react-router-dom';
import "./styles/LoginStyle.css";

const Header = (props) => {
  const [showmenu, setshowmenu] = useState(true);

  const handleDropdownMenu = () => {
    setshowmenu((p) => !p);
    if (showmenu) {
      document.getElementById("myDropdown").style.display = "block";
    }
    else {
      document.getElementById("myDropdown").style.display = "none";
    }
  }



  return (
    <div className="header">
      <div id="loginbtn" style={{ position: "absolute", right: "10%" }}> <NavLink exact activeClassName="active" to="/">Login</NavLink></div>
      <div id="registerbtn" style={{ position: "absolute", right: "2%" }} ><NavLink activeClassName="active" to="/register">Register</NavLink></div>
      
      <div id ="menubtn"
      style={{ display: "inline", left: "80%" }}>
      <NavLink activeClassName="active" to="/dashboard" >Home</NavLink>
          <NavLink activeClassName="active" to="/mytweets" >MyTweets</NavLink>
          <NavLink activeClassName="active" to="/allusers" >ShowAllUser</NavLink>
          <NavLink activeClassName="active" to="/resetPassword" >ResetPassword</NavLink>

          <NavLink activeClassName="active" to="/logout" >Logout</NavLink>
      </div> 
      
      
        
      </div>
    
  )
}

export default Header;