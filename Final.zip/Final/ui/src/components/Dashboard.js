import React, { useEffect, useState } from 'react';
import "./styles/LoginStyle.css";
import personLogo from "../components/images/person.jpg";
import Axios from "axios";
import { getUser, removeButtons, timeFormating } from '../Utils/Common';
import deleteLogo from "../components/images/like2.png";


const Dashboard = (props) => {
    const [userData, setuserData] = useState(null);
    removeButtons();

    document.title = "Tweets";

    const getTweets = () => {
        let getTweetUrl = " https://3suvrzt09c.execute-api.us-east-1.amazonaws.com/dev/gettweet";
        
        Axios.get(getTweetUrl)
            // eslint-disable-next-line
            .then((respons) => {
                console.log(respons.data);
                let tempdata = respons.data;
                tempdata.sort((a,b) => new Date(b.date)- new Date(a.date));
                console.log(tempdata);
                setuserData(tempdata);
            });
    }


    const handlePostTweet = (e) => {
        let tweetData = document.getElementById("textarea").value;
        if (tweetData.trim() !== "") {
            
            let tweetUrl = "https://3suvrzt09c.execute-api.us-east-1.amazonaws.com/dev/posttweet";
        

            let inputdata = {
                "emailId": getUser(),
                "tweetDesc": tweetData
            };
               
          

            Axios.post(tweetUrl, inputdata)
                // eslint-disable-next-line
                .then((respons) => {
                    document.getElementById("textarea").value = '';
                    getTweets();
                });
        }
        document.getElementById("textarea").value = '';
    }

    const handleLike = (e) => {
        if (e.target.style.backgroundColor !== "blue") {
            e.target.style.backgroundColor = "blue";
        }
        else {
            e.target.style.backgroundColor = "";
        }
    }

    const enableReply = (e) => {
        let elem = document.getElementById(e.target.id + "-replyDiv").style.display;
        if (elem === "block") {
            document.getElementById(e.target.id + "-replyDiv").style.display = "none";
        }
        else {
            document.getElementById(e.target.id + "-replyDiv").style.display = "block";
        }

    }
    const handlesendReply = (e) => {
        let replyData = document.getElementById(e.target.id + "-textBox").value;
        if (replyData !== "") {
            let replyUrl = "https://3suvrzt09c.execute-api.us-east-1.amazonaws.com/dev/reply";

            let inputdata = {
                "email": getUser(),
                "tweetId": e.target.id,
                "replyDesc": replyData,
                "date":new Date(),
            }

            Axios.post(replyUrl, inputdata)
                .then((res) => {
                    getTweets();
                })
        }
        document.getElementById(e.target.id + "-replyDiv").style.display = "none";
        document.getElementById(e.target.id + "-textBox").value = "";

    }


    useEffect(() => {
        getTweets();
    }, []);

    return (

        <div className="profileParent">
            <div >
                <textarea className="textBox" rows="3" id="textarea" placeholder="Type Your Tweet"></textarea>
                <input
                    type="button"
                    className="textBtn"
                    color="green"
                    onClick={handlePostTweet}
                    value="POST"
                />
            </div><br></br><br/>
            <div 
                 style={{ "margin-left": "20%",width:"150px",right:"50%"  }}>
                {userData && userData.map((item, index) => (
                    (item.tweetDescription !== "") && (
                        <div className="container-sm">
                        <div key={index}>
                            <div
                                className="usertweet-reply"
                                >
                                <div
                                    className="alltweet-wrapper">
                                    <img
                                        src={personLogo}
                                        alt="avatar"
                                        className="personImgUser">
                                    </img>
                                   
                                    <span
                                        style={{ "fontSize": "20px", "color": "black","fontWeight":"bold" }}>
                                        {item.tweetDescription}
                                    </span>
                                    <br /><br/>
                                    <div
                                        style={{ "position": "relative", "top": "-20px", "color": "black","fontWeight":"bold"  }}>
                                        Posted by {item.email}
                                        <span style={{ "paddingLeft": "4%", "color": "black","fontWeight":"bold" }}>
                                            {timeFormating(new Date(item.date))} ago
                                </span>
                                    </div>
                                    <label >
                                    <span
                                         type="button"
                                           className="replyText"
                                           id={item.id}
                                           onClick={enableReply}
                                       >Reply
                                   </span>
                                        <img
                                            
                                            src={deleteLogo}
                                            id={item.id}
                                            alt="delete"
                                            onClick={handleLike}
                                            className="likeLogo">
                                        </img>
                                       
                                    </label>
                                </div>
                               
                                {item.reply.length !== 0 &&
                                    item.reply.map((itm, index) => (

                                        <div
                                            className="replytweet-wrapper"
                                            key={index}
                                        >
                                            <img
                                                src={personLogo}
                                                alt="avatar"
                                                className="personImgUser">
                                            </img><br/>
                                            <span
                                                style={{ "fontSize": "20px", "color": "black","fontWeight":"bold" }}>
                                                {itm.replyDesc}
                                            </span><br/><br/>
                                            <label
                                                style={{ "position": "relative", "top": "-22px", "color": "black","fontWeight":"bold" }}>
                                                Commented by {itm.email}
                                                <span style={{ "paddingInline": "10%", "color": "black","fontWeight":"bold" }}>
                                                    {timeFormating(new Date(itm.date))} ago
                                </span>
                                            </label>
                                            
                                        </div>
                                    ))}
                                <div className="commentsdiv" id={item.id + "-replyDiv"}><br/>
                                   
                                    <textarea
                                        className="replyTextarea"
                                        rows="3"
                                        id={item.id + "-textBox"}
                                        placeholder="Post your reply"
                                    ></textarea><br/><br/>
                                     <input
                                        className="postcomment"
                                        type="button"
                                        value="post-comment"
                                        id={item.id}
                                        onClick={handlesendReply}
                                    />
                                </div>

                            </div>
                            <br />
                            
                        </div>
                        </div>
                    )
                ))}

            </div>
        </div>

    )
}

export default Dashboard;