import React, { useState } from "react";
import "./styles/LoginStyle.css";
import ReactLoading from 'react-loading';
import Axios from "axios";
import { getUser, removeButtons } from '../Utils/Common';



const ResetPassword = (props) => {

    document.title = "ResetPassword";
    const [userclassname, setuserclassname] = useState("field");
    const [passclassname, setpassclassname] = useState("field");
    const [load, setload] = useState(false);
    const [errmesg, seterrmesg] = useState("")
    let docu = document.getElementById("resetform");
    removeButtons();

    const handleResetPassword = (e) => {
        setload(true);
        
        let loginUrl = " https://3suvrzt09c.execute-api.us-east-1.amazonaws.com/dev/reset";

        let inputdata = {
            "oldpassword": docu.elements[1].value,
            "newpassword": docu.elements[2].value,
            "emailId": getUser()
        }

        Axios.put(loginUrl, inputdata)
            // eslint-disable-next-line
            .then((respons) => {
                console.log(respons.data);
                seterrmesg(respons.data.errorMessage);
                if (respons.data.successMessage === "Password Update Successfull" && respons.data.errorMessage === null) {
                   document.getElementById("resetMsg").style.color = "darkblue";
                    seterrmesg("Password Reset done.");
                    setTimeout(() => {
                        props.history.push('/dashboard');
                    }, 5000);
                }
                setload(false);
            });

    }


    return (
        <div>
            <form className="form-wrapper" id="resetform" >
                <h2 style={{ textAlign: "center" }}>Reset password</h2>
                <div className={userclassname}>
                    <input
                        id={1}
                        type="text"
                        value={getUser()}
                        onFocus={() => setuserclassname("field active")}
                        onBlur={() => setuserclassname("field")}
                        disabled
                    />
                    <label htmlFor={1}>
                        {"EmailId"}
                    </label>
                </div>
                <br />

                <div className={passclassname}>
                    <input
                        id={2}
                        type="password"
                        placeholder="Give your old Password"
                        onFocus={() => setpassclassname("field active")}
                        onBlur={() => setpassclassname("field")}
                        required
                    />
                    <label htmlFor={2}>
                        {"Old Password"}
                    </label>
                </div>
                <br />

                <div className={passclassname}>
                    <input
                        id={3}
                        type="password"
                        placeholder="Enter the new password"
                        onFocus={() => setpassclassname("field active")}
                        onBlur={() => setpassclassname("field")}
                        required
                    />
                    <label htmlFor={3}>
                        {"new Password"}
                    </label>
                </div>
                <br />


                <div className="field" style={{ height: "100%", background: "transparent" }}>
                    <input
                        type="button"
                        value="ResetPassword"
                        onClick={handleResetPassword}
                        style={{ background: "white" }}
                    />
                    <div className="loader" >
                        {load && <ReactLoading type="cubes" color="#E6E6E6" />}
                    </div>
                    <div id="errdiv" ><span id="resetMsg" className="errmsg">{errmesg}</span></div>
                </div>
            </form>
           
        </div>
    );
}


export default ResetPassword;