import React, { useState } from "react";
import "./styles/LoginStyle.css";
import { setUserSession, setTokenSession } from '../Utils/Common';
import ReactLoading from 'react-loading';
import Axios from "axios";



const Login = (props) => {

  document.title = "Login";
  const [userclassname, setuserclassname] = useState("field");
  const [passclassname, setpassclassname] = useState("field");
  const [load, setload] = useState(false);
  const [errmesg, seterrmesg] = useState("")
  let docu = document.getElementById("loginform");
   setTimeout(() => {
    let elem = document.getElementById("menubtn");
    if (elem !== null) {
     
    elem.style.display = "none";
    document.getElementById("loginbtn").style.display = "block";
    document.getElementById("registerbtn").style.display = "block";
    /*document.getElementById("menubtn").style.display = "none";*/
    }
     
   }, 10);
 

  const handleLogsubmit = (e) => {
    setload(true);

    let loginUrl = "http://localhost:8090/api/v1.0/tweets/login";

    let inputdata = {
      "email": docu.elements[0].value,
      "password": docu.elements[1].value,
    };

    Axios.post(loginUrl, inputdata)
      // eslint-disable-next-line
      .then((respons) => {
        console.log(respons.data);
        seterrmesg(respons.data.errorMessage);
        if (respons.data.status && respons.data.errorMessage === null) {
          let randnum = Math.random().toString().concat("0".repeat(3)).substr(2, 3).toString();
          setUserSession(respons.data.email);
          setTokenSession("R-" + randnum, respons.data.email);
          props.history.push('/dashboard');
        }
        // setload(false);
      });

  }


  return (
    <div>
      <form className="form-wrapper" id="loginform" >
        <h2 style={{ textAlign: "center" }}>LOGIN</h2>
        <div className={userclassname}>
          <input
            id={1}
            type="text"
            placeholder="Enter Username"
            onFocus={() => setuserclassname("field active")}
            onBlur={() => setuserclassname("field")}
            required
          />
          <label htmlFor={1}>
            {"Username"}
          </label>
        </div>
        <br />

        <div className={passclassname}>
          <input
            id={2}
            type="password"
            placeholder="Enter Password"
            onFocus={() => setpassclassname("field active")}
            onBlur={() => setpassclassname("field")}
            required
          />
          <label htmlFor={2}>
            {"Password"}
          </label>
        </div>
        <br />
        <div className="field" style={{ height: "100%", background: "transparent" }}>
          <input
            type="button"
            value="LOGIN"
            onClick={handleLogsubmit}
            style={{ background: "white" }}
          />
          <div className="loader" >
            {load && <ReactLoading type="cubes" color="#E6E6E6" />}
          </div><br /><br />

        </div><br />
       
      </form>
      <div id="errdiv" ><span className="errmsg">{errmesg}</span></div>
    </div>
  );
}


export default Login;