import React from 'react';
import "./styles/LoginStyle.css";
import { deleteToken} from '../Utils/Common';

const Logedout = (props) => {

    document.title = "Successfully LoggedOUT";
    document.getElementById("menubtn").innerHTML = "";
    
    deleteToken();
    props.history.push('/');

    return(
       
        <div>
        <h2>SUCCESSFULLY LOGGED OUT.....</h2>
        <div className="field" style={{ width: "30%", background: "white", height: "90%", }}>
         <input
          type='button'
          value="LOGIN"
          style={{ cursor: "pointer" }}
          onClick={()=> props.history.push('/')}
        />
      </div>
      </div>

    )
}

export default Logedout;